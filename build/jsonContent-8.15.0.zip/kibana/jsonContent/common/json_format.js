"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.JsonFormatEditorFactory = exports.JsonFormat = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _fieldTypes = require("@kbn/field-types");
var _common = require("@kbn/field-formats-plugin/common");
var _react = require("react");
// 1. Create a custom formatter by extending {@link FieldFormat}
class JsonFormat extends _common.FieldFormat {
  constructor(...args) {
    super(...args);
    // 4. Implement a conversion function
    (0, _defineProperty2.default)(this, "htmlConvert", val => {
      const {
        isJson,
        value
      } = getFormattedJson(String(val));
      if (!isJson) {
        return value;
      }
      return `<pre class='json-field'>${syntaxHighlightFormattedJson(value)}</pre>`;
    });
    (0, _defineProperty2.default)(this, "textConvert", val => {
      return getFormattedJson(String(val)).value;
    });
  }
  getParamDefaults() {
    return {};
  }
}

// add options for the format to be edited if required
exports.JsonFormat = JsonFormat;
(0, _defineProperty2.default)(JsonFormat, "id", 'json');
(0, _defineProperty2.default)(JsonFormat, "title", 'JSON');
// 2. Specify field types that this formatter supports
(0, _defineProperty2.default)(JsonFormat, "fieldType", _fieldTypes.KBN_FIELD_TYPES.STRING);
const JsonFormatEditor = () => /*#__PURE__*/(0, _react.createElement)('div', {});

// 2. Make sure it has a `formatId` that corresponds to format's id
JsonFormatEditor.formatId = JsonFormat.id;

// 3. Wrap editor component in a factory. This is needed to support and encourage code-splitting.
const JsonFormatEditorFactory = async () => JsonFormatEditor;
exports.JsonFormatEditorFactory = JsonFormatEditorFactory;
JsonFormatEditorFactory.formatId = JsonFormatEditor.formatId;

// syntax highlighting for JSON strings
// from ChatGPT
function syntaxHighlightFormattedJson(json) {
  // Replace specific parts of the JSON with colored spans
  json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return json.replace(/("(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*")(\s*:\s*)?|(\b(true|false|null)\b)|(-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match, key, stringVal, colon, literal, booleanOrNull, number) {
    if (key) {
      // If there's a colon after the string, it's a key
      return '<span class="key">' + key + '</span>' + (colon || '');
    } else if (booleanOrNull) {
      // Booleans and null
      return '<span class="boolean">' + booleanOrNull + '</span>';
    } else if (number) {
      // Numbers
      return '<span class="number">' + number + '</span>';
    }
    // Strings
    return '<span class="string">' + match + '</span>';
  });
}

/**
 * Returns a formatted JSON string if the input is a valid JSON string,
 * otherwise returns the input string as is.
 * @param value {"abcd":true}
 * @returns {} '{ isJson: true, value: "{\n \"abcd\": true\n}" }'
 */
function getFormattedJson(value) {
  try {
    const obj = JSON.parse(value);
    return {
      isJson: true,
      value: JSON.stringify(obj, null, 2)
    };
  } catch {
    return {
      isJson: false,
      value
    };
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZmllbGRUeXBlcyIsInJlcXVpcmUiLCJfY29tbW9uIiwiX3JlYWN0IiwiSnNvbkZvcm1hdCIsIkZpZWxkRm9ybWF0IiwiY29uc3RydWN0b3IiLCJhcmdzIiwiX2RlZmluZVByb3BlcnR5MiIsImRlZmF1bHQiLCJ2YWwiLCJpc0pzb24iLCJ2YWx1ZSIsImdldEZvcm1hdHRlZEpzb24iLCJTdHJpbmciLCJzeW50YXhIaWdobGlnaHRGb3JtYXR0ZWRKc29uIiwiZ2V0UGFyYW1EZWZhdWx0cyIsImV4cG9ydHMiLCJLQk5fRklFTERfVFlQRVMiLCJTVFJJTkciLCJKc29uRm9ybWF0RWRpdG9yIiwiY3JlYXRlRWxlbWVudCIsImZvcm1hdElkIiwiaWQiLCJKc29uRm9ybWF0RWRpdG9yRmFjdG9yeSIsImpzb24iLCJyZXBsYWNlIiwibWF0Y2giLCJrZXkiLCJzdHJpbmdWYWwiLCJjb2xvbiIsImxpdGVyYWwiLCJib29sZWFuT3JOdWxsIiwibnVtYmVyIiwib2JqIiwiSlNPTiIsInBhcnNlIiwic3RyaW5naWZ5Il0sInNvdXJjZXMiOlsianNvbl9mb3JtYXQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgS0JOX0ZJRUxEX1RZUEVTIH0gZnJvbSAnQGtibi9maWVsZC10eXBlcyc7XG5pbXBvcnQgeyBGaWVsZEZvcm1hdCwgRmllbGRGb3JtYXRQYXJhbXMsIHR5cGUgSHRtbENvbnRleHRUeXBlQ29udmVydCwgdHlwZSBUZXh0Q29udGV4dFR5cGVDb252ZXJ0IH0gZnJvbSAnQGtibi9maWVsZC1mb3JtYXRzLXBsdWdpbi9jb21tb24nO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gJ3JlYWN0JztcblxuLy8gMS4gQ3JlYXRlIGEgY3VzdG9tIGZvcm1hdHRlciBieSBleHRlbmRpbmcge0BsaW5rIEZpZWxkRm9ybWF0fVxuZXhwb3J0IGNsYXNzIEpzb25Gb3JtYXQgZXh0ZW5kcyBGaWVsZEZvcm1hdCB7XG4gIHN0YXRpYyBpZCA9ICdqc29uJztcbiAgc3RhdGljIHRpdGxlID0gJ0pTT04nO1xuXG4gIC8vIDIuIFNwZWNpZnkgZmllbGQgdHlwZXMgdGhhdCB0aGlzIGZvcm1hdHRlciBzdXBwb3J0c1xuICBzdGF0aWMgZmllbGRUeXBlID0gS0JOX0ZJRUxEX1RZUEVTLlNUUklORztcblxuICBnZXRQYXJhbURlZmF1bHRzKCk6IEZpZWxkRm9ybWF0UGFyYW1zIHtcbiAgICByZXR1cm4ge31cbiAgfVxuXG4gIC8vIDQuIEltcGxlbWVudCBhIGNvbnZlcnNpb24gZnVuY3Rpb25cbiAgaHRtbENvbnZlcnQ6IEh0bWxDb250ZXh0VHlwZUNvbnZlcnQgPSAodmFsKSA9PiB7XG4gICAgY29uc3QgeyBpc0pzb24sIHZhbHVlIH0gPSBnZXRGb3JtYXR0ZWRKc29uKFN0cmluZyh2YWwpKVxuICAgIGlmKCFpc0pzb24pIHtcbiAgICAgIHJldHVybiB2YWx1ZVxuICAgIH1cblxuICAgIHJldHVybiBgPHByZSBjbGFzcz0nanNvbi1maWVsZCc+JHtzeW50YXhIaWdobGlnaHRGb3JtYXR0ZWRKc29uKHZhbHVlKX08L3ByZT5gXG4gIH1cblxuICB0ZXh0Q29udmVydDogVGV4dENvbnRleHRUeXBlQ29udmVydCA9ICh2YWwpID0+IHtcbiAgICByZXR1cm4gZ2V0Rm9ybWF0dGVkSnNvbihTdHJpbmcodmFsKSkudmFsdWVcbiAgfVxufVxuXG4vLyBhZGQgb3B0aW9ucyBmb3IgdGhlIGZvcm1hdCB0byBiZSBlZGl0ZWQgaWYgcmVxdWlyZWRcbmNvbnN0IEpzb25Gb3JtYXRFZGl0b3IgPSAoKSA9PiBjcmVhdGVFbGVtZW50KCdkaXYnLCB7fSlcblxuLy8gMi4gTWFrZSBzdXJlIGl0IGhhcyBhIGBmb3JtYXRJZGAgdGhhdCBjb3JyZXNwb25kcyB0byBmb3JtYXQncyBpZFxuSnNvbkZvcm1hdEVkaXRvci5mb3JtYXRJZCA9IEpzb25Gb3JtYXQuaWQ7XG5cbi8vIDMuIFdyYXAgZWRpdG9yIGNvbXBvbmVudCBpbiBhIGZhY3RvcnkuIFRoaXMgaXMgbmVlZGVkIHRvIHN1cHBvcnQgYW5kIGVuY291cmFnZSBjb2RlLXNwbGl0dGluZy5cbmV4cG9ydCBjb25zdCBKc29uRm9ybWF0RWRpdG9yRmFjdG9yeSA9IGFzeW5jICgpID0+IEpzb25Gb3JtYXRFZGl0b3I7XG5Kc29uRm9ybWF0RWRpdG9yRmFjdG9yeS5mb3JtYXRJZCA9IEpzb25Gb3JtYXRFZGl0b3IuZm9ybWF0SWQ7XG5cbi8vIHN5bnRheCBoaWdobGlnaHRpbmcgZm9yIEpTT04gc3RyaW5nc1xuLy8gZnJvbSBDaGF0R1BUXG5mdW5jdGlvbiBzeW50YXhIaWdobGlnaHRGb3JtYXR0ZWRKc29uKGpzb246IHN0cmluZykge1xuICAvLyBSZXBsYWNlIHNwZWNpZmljIHBhcnRzIG9mIHRoZSBKU09OIHdpdGggY29sb3JlZCBzcGFuc1xuICBqc29uID0ganNvblxuICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7Jyk7XG4gIHJldHVybiBqc29uLnJlcGxhY2UoLyhcIihcXFxcdVtcXGRhLWZBLUZdezR9fFxcXFxbXnVdfFteXFxcXFwiXSkqXCIpKFxccyo6XFxzKik/fChcXGIodHJ1ZXxmYWxzZXxudWxsKVxcYil8KC0/XFxkKyg/OlxcLlxcZCopPyg/OltlRV1bK1xcLV0/XFxkKyk/KS9nLCBmdW5jdGlvbiAobWF0Y2gsIGtleSwgc3RyaW5nVmFsLCBjb2xvbiwgbGl0ZXJhbCwgYm9vbGVhbk9yTnVsbCwgbnVtYmVyKSB7XG4gICAgaWYgKGtleSkge1xuICAgICAgLy8gSWYgdGhlcmUncyBhIGNvbG9uIGFmdGVyIHRoZSBzdHJpbmcsIGl0J3MgYSBrZXlcbiAgICAgIHJldHVybiAnPHNwYW4gY2xhc3M9XCJrZXlcIj4nICsga2V5ICsgJzwvc3Bhbj4nICsgKGNvbG9uIHx8ICcnKTtcbiAgICB9IGVsc2UgaWYgKGJvb2xlYW5Pck51bGwpIHtcbiAgICAgIC8vIEJvb2xlYW5zIGFuZCBudWxsXG4gICAgICByZXR1cm4gJzxzcGFuIGNsYXNzPVwiYm9vbGVhblwiPicgKyBib29sZWFuT3JOdWxsICsgJzwvc3Bhbj4nO1xuICAgIH0gZWxzZSBpZiAobnVtYmVyKSB7XG4gICAgICAvLyBOdW1iZXJzXG4gICAgICByZXR1cm4gJzxzcGFuIGNsYXNzPVwibnVtYmVyXCI+JyArIG51bWJlciArICc8L3NwYW4+JztcbiAgICB9XG4gICAgLy8gU3RyaW5nc1xuICAgIHJldHVybiAnPHNwYW4gY2xhc3M9XCJzdHJpbmdcIj4nICsgbWF0Y2ggKyAnPC9zcGFuPic7XG4gIH0pXG59XG5cbi8qKlxuICogUmV0dXJucyBhIGZvcm1hdHRlZCBKU09OIHN0cmluZyBpZiB0aGUgaW5wdXQgaXMgYSB2YWxpZCBKU09OIHN0cmluZyxcbiAqIG90aGVyd2lzZSByZXR1cm5zIHRoZSBpbnB1dCBzdHJpbmcgYXMgaXMuXG4gKiBAcGFyYW0gdmFsdWUge1wiYWJjZFwiOnRydWV9XG4gKiBAcmV0dXJucyB7fSAneyBpc0pzb246IHRydWUsIHZhbHVlOiBcIntcXG4gXFxcImFiY2RcXFwiOiB0cnVlXFxufVwiIH0nXG4gKi9cbmZ1bmN0aW9uIGdldEZvcm1hdHRlZEpzb24odmFsdWU6IHN0cmluZykge1xuICB0cnkge1xuICAgIGNvbnN0IG9iaiA9IEpTT04ucGFyc2UodmFsdWUpXG4gICAgcmV0dXJuIHtcbiAgICAgIGlzSnNvbjogdHJ1ZSxcbiAgICAgIHZhbHVlOiBKU09OLnN0cmluZ2lmeShvYmosIG51bGwsIDIpXG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBpc0pzb246IGZhbHNlLCB2YWx1ZSB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFBQSxXQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFFQTtBQUNPLE1BQU1HLFVBQVUsU0FBU0MsbUJBQVcsQ0FBQztFQUFBQyxZQUFBLEdBQUFDLElBQUE7SUFBQSxTQUFBQSxJQUFBO0lBVzFDO0lBQUEsSUFBQUMsZ0JBQUEsQ0FBQUMsT0FBQSx1QkFDdUNDLEdBQUcsSUFBSztNQUM3QyxNQUFNO1FBQUVDLE1BQU07UUFBRUM7TUFBTSxDQUFDLEdBQUdDLGdCQUFnQixDQUFDQyxNQUFNLENBQUNKLEdBQUcsQ0FBQyxDQUFDO01BQ3ZELElBQUcsQ0FBQ0MsTUFBTSxFQUFFO1FBQ1YsT0FBT0MsS0FBSztNQUNkO01BRUEsT0FBTywyQkFBMkJHLDRCQUE0QixDQUFDSCxLQUFLLENBQUMsUUFBUTtJQUMvRSxDQUFDO0lBQUEsSUFBQUosZ0JBQUEsQ0FBQUMsT0FBQSx1QkFFc0NDLEdBQUcsSUFBSztNQUM3QyxPQUFPRyxnQkFBZ0IsQ0FBQ0MsTUFBTSxDQUFDSixHQUFHLENBQUMsQ0FBQyxDQUFDRSxLQUFLO0lBQzVDLENBQUM7RUFBQTtFQWhCREksZ0JBQWdCQSxDQUFBLEVBQXNCO0lBQ3BDLE9BQU8sQ0FBQyxDQUFDO0VBQ1g7QUFlRjs7QUFFQTtBQUFBQyxPQUFBLENBQUFiLFVBQUEsR0FBQUEsVUFBQTtBQUFBLElBQUFJLGdCQUFBLENBQUFDLE9BQUEsRUExQmFMLFVBQVUsUUFDVCxNQUFNO0FBQUEsSUFBQUksZ0JBQUEsQ0FBQUMsT0FBQSxFQURQTCxVQUFVLFdBRU4sTUFBTTtBQUVyQjtBQUFBLElBQUFJLGdCQUFBLENBQUFDLE9BQUEsRUFKV0wsVUFBVSxlQUtGYywyQkFBZSxDQUFDQyxNQUFNO0FBc0IzQyxNQUFNQyxnQkFBZ0IsR0FBR0EsQ0FBQSxrQkFBTSxJQUFBQyxvQkFBYSxFQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQzs7QUFFdkQ7QUFDQUQsZ0JBQWdCLENBQUNFLFFBQVEsR0FBR2xCLFVBQVUsQ0FBQ21CLEVBQUU7O0FBRXpDO0FBQ08sTUFBTUMsdUJBQXVCLEdBQUcsTUFBQUEsQ0FBQSxLQUFZSixnQkFBZ0I7QUFBQ0gsT0FBQSxDQUFBTyx1QkFBQSxHQUFBQSx1QkFBQTtBQUNwRUEsdUJBQXVCLENBQUNGLFFBQVEsR0FBR0YsZ0JBQWdCLENBQUNFLFFBQVE7O0FBRTVEO0FBQ0E7QUFDQSxTQUFTUCw0QkFBNEJBLENBQUNVLElBQVksRUFBRTtFQUNsRDtFQUNBQSxJQUFJLEdBQUdBLElBQUksQ0FDUkMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FDdEJBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQ3JCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUN4QixPQUFPRCxJQUFJLENBQUNDLE9BQU8sQ0FBQyw4R0FBOEcsRUFBRSxVQUFVQyxLQUFLLEVBQUVDLEdBQUcsRUFBRUMsU0FBUyxFQUFFQyxLQUFLLEVBQUVDLE9BQU8sRUFBRUMsYUFBYSxFQUFFQyxNQUFNLEVBQUU7SUFDMU0sSUFBSUwsR0FBRyxFQUFFO01BQ1A7TUFDQSxPQUFPLG9CQUFvQixHQUFHQSxHQUFHLEdBQUcsU0FBUyxJQUFJRSxLQUFLLElBQUksRUFBRSxDQUFDO0lBQy9ELENBQUMsTUFBTSxJQUFJRSxhQUFhLEVBQUU7TUFDeEI7TUFDQSxPQUFPLHdCQUF3QixHQUFHQSxhQUFhLEdBQUcsU0FBUztJQUM3RCxDQUFDLE1BQU0sSUFBSUMsTUFBTSxFQUFFO01BQ2pCO01BQ0EsT0FBTyx1QkFBdUIsR0FBR0EsTUFBTSxHQUFHLFNBQVM7SUFDckQ7SUFDQTtJQUNBLE9BQU8sdUJBQXVCLEdBQUdOLEtBQUssR0FBRyxTQUFTO0VBQ3BELENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNkLGdCQUFnQkEsQ0FBQ0QsS0FBYSxFQUFFO0VBQ3ZDLElBQUk7SUFDRixNQUFNc0IsR0FBRyxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQ3hCLEtBQUssQ0FBQztJQUM3QixPQUFPO01BQ0xELE1BQU0sRUFBRSxJQUFJO01BQ1pDLEtBQUssRUFBRXVCLElBQUksQ0FBQ0UsU0FBUyxDQUFDSCxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7SUFDcEMsQ0FBQztFQUNILENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBTztNQUFFdkIsTUFBTSxFQUFFLEtBQUs7TUFBRUM7SUFBTSxDQUFDO0VBQ2pDO0FBQ0YiLCJpZ25vcmVMaXN0IjpbXX0=