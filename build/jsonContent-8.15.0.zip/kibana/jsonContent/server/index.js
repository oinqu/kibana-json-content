"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
async function plugin() {
  const {
    JsonContentPlugin
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('../common/plugin')));
  return new JsonContentPlugin();
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwbHVnaW4iLCJKc29uQ29udGVudFBsdWdpbiIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwicmVxdWlyZSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBhc3luYyBmdW5jdGlvbiBwbHVnaW4oKSB7XG4gIGNvbnN0IHsgSnNvbkNvbnRlbnRQbHVnaW4gfSA9IGF3YWl0IGltcG9ydCgnLi4vY29tbW9uL3BsdWdpbicpO1xuICByZXR1cm4gbmV3IEpzb25Db250ZW50UGx1Z2luKCk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQU8sZUFBZUEsTUFBTUEsQ0FBQSxFQUFHO0VBQzdCLE1BQU07SUFBRUM7RUFBa0IsQ0FBQyxHQUFHLE1BQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUFDLHVCQUFBLENBQUFDLE9BQUEsQ0FBYSxrQkFBa0IsR0FBQztFQUM5RCxPQUFPLElBQUlMLGlCQUFpQixDQUFDLENBQUM7QUFDaEMiLCJpZ25vcmVMaXN0IjpbXX0=