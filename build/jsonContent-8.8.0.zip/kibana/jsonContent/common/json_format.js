"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.JsonFormatEditorFactory = exports.JsonFormat = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _react = require("react");
var _common = require("@kbn/field-formats-plugin/common");
var _fieldTypes = require("@kbn/field-types");
// 1. Create a custom formatter by extending {@link FieldFormat}
class JsonFormat extends _common.FieldFormat {
  constructor(...args) {
    super(...args);
    // 4. Implement a conversion function
    (0, _defineProperty2.default)(this, "htmlConvert", val => {
      const {
        isJson,
        value
      } = getFormattedJson(String(val));
      if (!isJson) {
        return value;
      }
      return `<pre class='json-field'>${syntaxHighlightFormattedJson(value)}</pre>`;
    });
    (0, _defineProperty2.default)(this, "textConvert", val => {
      return getFormattedJson(String(val)).value;
    });
  }
  getParamDefaults() {
    return {};
  }
}

// add options for the format to be edited if required
exports.JsonFormat = JsonFormat;
(0, _defineProperty2.default)(JsonFormat, "id", 'json');
(0, _defineProperty2.default)(JsonFormat, "title", 'JSON');
// 2. Specify field types that this formatter supports
(0, _defineProperty2.default)(JsonFormat, "fieldType", _fieldTypes.KBN_FIELD_TYPES.STRING);
const JsonFormatEditor = () => /*#__PURE__*/(0, _react.createElement)('div', {});

// 2. Make sure it has a `formatId` that corresponds to format's id
JsonFormatEditor.formatId = JsonFormat.id;

// 3. Wrap editor component in a factory. This is needed to support and encourage code-splitting.
const JsonFormatEditorFactory = async () => JsonFormatEditor;
exports.JsonFormatEditorFactory = JsonFormatEditorFactory;
JsonFormatEditorFactory.formatId = JsonFormatEditor.formatId;

// syntax highlighting for JSON strings
// from ChatGPT
function syntaxHighlightFormattedJson(json) {
  // Replace specific parts of the JSON with colored spans
  json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return json.replace(/("(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*")(\s*:\s*)?|(\b(true|false|null)\b)|(-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, (match, key, stringVal, colon, literal, booleanOrNull, number) => {
    if (key) {
      // If there's a colon after the string, it's a key
      return '<span class="key">' + key + '</span>' + (colon || '');
    } else if (booleanOrNull) {
      // Booleans and null
      return '<span class="boolean">' + booleanOrNull + '</span>';
    } else if (number) {
      // Numbers
      return '<span class="number">' + number + '</span>';
    }

    // Strings
    return '<span class="string">' + match + '</span>';
  });
}

/**
 * Returns a formatted JSON string if the input is a valid JSON string,
 * otherwise returns the input string as is.
 * @param value {"abcd":true}
 * @returns {} '{ isJson: true, value: "{\n \"abcd\": true\n}" }'
 */
function getFormattedJson(value) {
  try {
    const obj = JSON.parse(value);
    return {
      isJson: true,
      value: JSON.stringify(obj, null, 2)
    };
  } catch {
    return {
      isJson: false,
      value
    };
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NvbW1vbiIsIl9maWVsZFR5cGVzIiwiSnNvbkZvcm1hdCIsIkZpZWxkRm9ybWF0IiwiY29uc3RydWN0b3IiLCJhcmdzIiwiX2RlZmluZVByb3BlcnR5MiIsImRlZmF1bHQiLCJ2YWwiLCJpc0pzb24iLCJ2YWx1ZSIsImdldEZvcm1hdHRlZEpzb24iLCJTdHJpbmciLCJzeW50YXhIaWdobGlnaHRGb3JtYXR0ZWRKc29uIiwiZ2V0UGFyYW1EZWZhdWx0cyIsImV4cG9ydHMiLCJLQk5fRklFTERfVFlQRVMiLCJTVFJJTkciLCJKc29uRm9ybWF0RWRpdG9yIiwiY3JlYXRlRWxlbWVudCIsImZvcm1hdElkIiwiaWQiLCJKc29uRm9ybWF0RWRpdG9yRmFjdG9yeSIsImpzb24iLCJyZXBsYWNlIiwibWF0Y2giLCJrZXkiLCJzdHJpbmdWYWwiLCJjb2xvbiIsImxpdGVyYWwiLCJib29sZWFuT3JOdWxsIiwibnVtYmVyIiwib2JqIiwiSlNPTiIsInBhcnNlIiwic3RyaW5naWZ5Il0sInNvdXJjZXMiOlsianNvbl9mb3JtYXQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgRmllbGRGb3JtYXQsIEZpZWxkRm9ybWF0UGFyYW1zLCB0eXBlIEh0bWxDb250ZXh0VHlwZUNvbnZlcnQsIHR5cGUgVGV4dENvbnRleHRUeXBlQ29udmVydCB9IGZyb20gJ0BrYm4vZmllbGQtZm9ybWF0cy1wbHVnaW4vY29tbW9uJ1xuaW1wb3J0IHsgS0JOX0ZJRUxEX1RZUEVTIH0gZnJvbSAnQGtibi9maWVsZC10eXBlcydcblxuLy8gMS4gQ3JlYXRlIGEgY3VzdG9tIGZvcm1hdHRlciBieSBleHRlbmRpbmcge0BsaW5rIEZpZWxkRm9ybWF0fVxuZXhwb3J0IGNsYXNzIEpzb25Gb3JtYXQgZXh0ZW5kcyBGaWVsZEZvcm1hdCB7XG5cdHN0YXRpYyBpZCA9ICdqc29uJ1xuXHRzdGF0aWMgdGl0bGUgPSAnSlNPTidcblxuXHQvLyAyLiBTcGVjaWZ5IGZpZWxkIHR5cGVzIHRoYXQgdGhpcyBmb3JtYXR0ZXIgc3VwcG9ydHNcblx0c3RhdGljIGZpZWxkVHlwZSA9IEtCTl9GSUVMRF9UWVBFUy5TVFJJTkdcblxuXHRnZXRQYXJhbURlZmF1bHRzKCk6IEZpZWxkRm9ybWF0UGFyYW1zIHtcblx0XHRyZXR1cm4ge31cblx0fVxuXG5cdC8vIDQuIEltcGxlbWVudCBhIGNvbnZlcnNpb24gZnVuY3Rpb25cblx0aHRtbENvbnZlcnQ6IEh0bWxDb250ZXh0VHlwZUNvbnZlcnQgPSAodmFsKSA9PiB7XG5cdFx0Y29uc3QgeyBpc0pzb24sIHZhbHVlIH0gPSBnZXRGb3JtYXR0ZWRKc29uKFN0cmluZyh2YWwpKVxuXHRcdGlmKCFpc0pzb24pIHtcblx0XHRcdHJldHVybiB2YWx1ZVxuXHRcdH1cblxuXHRcdHJldHVybiBgPHByZSBjbGFzcz0nanNvbi1maWVsZCc+JHtzeW50YXhIaWdobGlnaHRGb3JtYXR0ZWRKc29uKHZhbHVlKX08L3ByZT5gXG5cdH1cblxuXHR0ZXh0Q29udmVydDogVGV4dENvbnRleHRUeXBlQ29udmVydCA9ICh2YWwpID0+IHtcblx0XHRyZXR1cm4gZ2V0Rm9ybWF0dGVkSnNvbihTdHJpbmcodmFsKSkudmFsdWVcblx0fVxufVxuXG4vLyBhZGQgb3B0aW9ucyBmb3IgdGhlIGZvcm1hdCB0byBiZSBlZGl0ZWQgaWYgcmVxdWlyZWRcbmNvbnN0IEpzb25Gb3JtYXRFZGl0b3IgPSAoKSA9PiBjcmVhdGVFbGVtZW50KCdkaXYnLCB7fSlcblxuLy8gMi4gTWFrZSBzdXJlIGl0IGhhcyBhIGBmb3JtYXRJZGAgdGhhdCBjb3JyZXNwb25kcyB0byBmb3JtYXQncyBpZFxuSnNvbkZvcm1hdEVkaXRvci5mb3JtYXRJZCA9IEpzb25Gb3JtYXQuaWRcblxuLy8gMy4gV3JhcCBlZGl0b3IgY29tcG9uZW50IGluIGEgZmFjdG9yeS4gVGhpcyBpcyBuZWVkZWQgdG8gc3VwcG9ydCBhbmQgZW5jb3VyYWdlIGNvZGUtc3BsaXR0aW5nLlxuZXhwb3J0IGNvbnN0IEpzb25Gb3JtYXRFZGl0b3JGYWN0b3J5ID0gYXN5bmMoKSA9PiBKc29uRm9ybWF0RWRpdG9yXG5Kc29uRm9ybWF0RWRpdG9yRmFjdG9yeS5mb3JtYXRJZCA9IEpzb25Gb3JtYXRFZGl0b3IuZm9ybWF0SWRcblxuLy8gc3ludGF4IGhpZ2hsaWdodGluZyBmb3IgSlNPTiBzdHJpbmdzXG4vLyBmcm9tIENoYXRHUFRcbmZ1bmN0aW9uIHN5bnRheEhpZ2hsaWdodEZvcm1hdHRlZEpzb24oanNvbjogc3RyaW5nKSB7XG5cdC8vIFJlcGxhY2Ugc3BlY2lmaWMgcGFydHMgb2YgdGhlIEpTT04gd2l0aCBjb2xvcmVkIHNwYW5zXG5cdGpzb24gPSBqc29uXG5cdFx0LnJlcGxhY2UoLyYvZywgJyZhbXA7Jylcblx0XHQucmVwbGFjZSgvPC9nLCAnJmx0OycpXG5cdFx0LnJlcGxhY2UoLz4vZywgJyZndDsnKVxuXHRyZXR1cm4ganNvbi5yZXBsYWNlKC8oXCIoXFxcXHVbXFxkYS1mQS1GXXs0fXxcXFxcW151XXxbXlxcXFxcIl0pKlwiKShcXHMqOlxccyopP3woXFxiKHRydWV8ZmFsc2V8bnVsbClcXGIpfCgtP1xcZCsoPzpcXC5cXGQqKT8oPzpbZUVdWytcXC1dP1xcZCspPykvZywgKG1hdGNoLCBrZXksIHN0cmluZ1ZhbCwgY29sb24sIGxpdGVyYWwsIGJvb2xlYW5Pck51bGwsIG51bWJlcikgPT4ge1xuXHRcdGlmKGtleSkge1xuXHRcdFx0Ly8gSWYgdGhlcmUncyBhIGNvbG9uIGFmdGVyIHRoZSBzdHJpbmcsIGl0J3MgYSBrZXlcblx0XHRcdHJldHVybiAnPHNwYW4gY2xhc3M9XCJrZXlcIj4nICsga2V5ICsgJzwvc3Bhbj4nICsgKGNvbG9uIHx8ICcnKVxuXHRcdH0gZWxzZSBpZihib29sZWFuT3JOdWxsKSB7XG5cdFx0XHQvLyBCb29sZWFucyBhbmQgbnVsbFxuXHRcdFx0cmV0dXJuICc8c3BhbiBjbGFzcz1cImJvb2xlYW5cIj4nICsgYm9vbGVhbk9yTnVsbCArICc8L3NwYW4+J1xuXHRcdH0gZWxzZSBpZihudW1iZXIpIHtcblx0XHRcdC8vIE51bWJlcnNcblx0XHRcdHJldHVybiAnPHNwYW4gY2xhc3M9XCJudW1iZXJcIj4nICsgbnVtYmVyICsgJzwvc3Bhbj4nXG5cdFx0fVxuXG5cdFx0Ly8gU3RyaW5nc1xuXHRcdHJldHVybiAnPHNwYW4gY2xhc3M9XCJzdHJpbmdcIj4nICsgbWF0Y2ggKyAnPC9zcGFuPidcblx0fSlcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgZm9ybWF0dGVkIEpTT04gc3RyaW5nIGlmIHRoZSBpbnB1dCBpcyBhIHZhbGlkIEpTT04gc3RyaW5nLFxuICogb3RoZXJ3aXNlIHJldHVybnMgdGhlIGlucHV0IHN0cmluZyBhcyBpcy5cbiAqIEBwYXJhbSB2YWx1ZSB7XCJhYmNkXCI6dHJ1ZX1cbiAqIEByZXR1cm5zIHt9ICd7IGlzSnNvbjogdHJ1ZSwgdmFsdWU6IFwie1xcbiBcXFwiYWJjZFxcXCI6IHRydWVcXG59XCIgfSdcbiAqL1xuZnVuY3Rpb24gZ2V0Rm9ybWF0dGVkSnNvbih2YWx1ZTogc3RyaW5nKSB7XG5cdHRyeSB7XG5cdFx0Y29uc3Qgb2JqID0gSlNPTi5wYXJzZSh2YWx1ZSlcblx0XHRyZXR1cm4ge1xuXHRcdFx0aXNKc29uOiB0cnVlLFxuXHRcdFx0dmFsdWU6IEpTT04uc3RyaW5naWZ5KG9iaiwgbnVsbCwgMilcblx0XHR9XG5cdH0gY2F0Y2h7XG5cdFx0cmV0dXJuIHsgaXNKc29uOiBmYWxzZSwgdmFsdWUgfVxuXHR9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBRUE7QUFDTyxNQUFNRyxVQUFVLFNBQVNDLG1CQUFXLENBQUM7RUFBQUMsWUFBQSxHQUFBQyxJQUFBO0lBQUEsU0FBQUEsSUFBQTtJQVczQztJQUFBLElBQUFDLGdCQUFBLENBQUFDLE9BQUEsdUJBQ3VDQyxHQUFHLElBQUs7TUFDOUMsTUFBTTtRQUFFQyxNQUFNO1FBQUVDO01BQU0sQ0FBQyxHQUFHQyxnQkFBZ0IsQ0FBQ0MsTUFBTSxDQUFDSixHQUFHLENBQUMsQ0FBQztNQUN2RCxJQUFHLENBQUNDLE1BQU0sRUFBRTtRQUNYLE9BQU9DLEtBQUs7TUFDYjtNQUVBLE9BQVEsMkJBQTBCRyw0QkFBNEIsQ0FBQ0gsS0FBSyxDQUFFLFFBQU87SUFDOUUsQ0FBQztJQUFBLElBQUFKLGdCQUFBLENBQUFDLE9BQUEsdUJBRXNDQyxHQUFHLElBQUs7TUFDOUMsT0FBT0csZ0JBQWdCLENBQUNDLE1BQU0sQ0FBQ0osR0FBRyxDQUFDLENBQUMsQ0FBQ0UsS0FBSztJQUMzQyxDQUFDO0VBQUE7RUFoQkRJLGdCQUFnQkEsQ0FBQSxFQUFzQjtJQUNyQyxPQUFPLENBQUMsQ0FBQztFQUNWO0FBZUQ7O0FBRUE7QUFBQUMsT0FBQSxDQUFBYixVQUFBLEdBQUFBLFVBQUE7QUFBQSxJQUFBSSxnQkFBQSxDQUFBQyxPQUFBLEVBMUJhTCxVQUFVLFFBQ1YsTUFBTTtBQUFBLElBQUFJLGdCQUFBLENBQUFDLE9BQUEsRUFETkwsVUFBVSxXQUVQLE1BQU07QUFFckI7QUFBQSxJQUFBSSxnQkFBQSxDQUFBQyxPQUFBLEVBSllMLFVBQVUsZUFLSGMsMkJBQWUsQ0FBQ0MsTUFBTTtBQXNCMUMsTUFBTUMsZ0JBQWdCLEdBQUdBLENBQUEsa0JBQU0sSUFBQUMsb0JBQWEsRUFBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7O0FBRXZEO0FBQ0FELGdCQUFnQixDQUFDRSxRQUFRLEdBQUdsQixVQUFVLENBQUNtQixFQUFFOztBQUV6QztBQUNPLE1BQU1DLHVCQUF1QixHQUFHLE1BQUFBLENBQUEsS0FBV0osZ0JBQWdCO0FBQUFILE9BQUEsQ0FBQU8sdUJBQUEsR0FBQUEsdUJBQUE7QUFDbEVBLHVCQUF1QixDQUFDRixRQUFRLEdBQUdGLGdCQUFnQixDQUFDRSxRQUFROztBQUU1RDtBQUNBO0FBQ0EsU0FBU1AsNEJBQTRCQSxDQUFDVSxJQUFZLEVBQUU7RUFDbkQ7RUFDQUEsSUFBSSxHQUFHQSxJQUFJLENBQ1RDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQ3RCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUNyQkEsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7RUFDdkIsT0FBT0QsSUFBSSxDQUFDQyxPQUFPLENBQUMsOEdBQThHLEVBQUUsQ0FBQ0MsS0FBSyxFQUFFQyxHQUFHLEVBQUVDLFNBQVMsRUFBRUMsS0FBSyxFQUFFQyxPQUFPLEVBQUVDLGFBQWEsRUFBRUMsTUFBTSxLQUFLO0lBQ3JNLElBQUdMLEdBQUcsRUFBRTtNQUNQO01BQ0EsT0FBTyxvQkFBb0IsR0FBR0EsR0FBRyxHQUFHLFNBQVMsSUFBSUUsS0FBSyxJQUFJLEVBQUUsQ0FBQztJQUM5RCxDQUFDLE1BQU0sSUFBR0UsYUFBYSxFQUFFO01BQ3hCO01BQ0EsT0FBTyx3QkFBd0IsR0FBR0EsYUFBYSxHQUFHLFNBQVM7SUFDNUQsQ0FBQyxNQUFNLElBQUdDLE1BQU0sRUFBRTtNQUNqQjtNQUNBLE9BQU8sdUJBQXVCLEdBQUdBLE1BQU0sR0FBRyxTQUFTO0lBQ3BEOztJQUVBO0lBQ0EsT0FBTyx1QkFBdUIsR0FBR04sS0FBSyxHQUFHLFNBQVM7RUFDbkQsQ0FBQyxDQUFDO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU2QsZ0JBQWdCQSxDQUFDRCxLQUFhLEVBQUU7RUFDeEMsSUFBSTtJQUNILE1BQU1zQixHQUFHLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDeEIsS0FBSyxDQUFDO0lBQzdCLE9BQU87TUFDTkQsTUFBTSxFQUFFLElBQUk7TUFDWkMsS0FBSyxFQUFFdUIsSUFBSSxDQUFDRSxTQUFTLENBQUNILEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0VBQ0YsQ0FBQyxDQUFDLE1BQUs7SUFDTixPQUFPO01BQUV2QixNQUFNLEVBQUUsS0FBSztNQUFFQztJQUFNLENBQUM7RUFDaEM7QUFDRCJ9